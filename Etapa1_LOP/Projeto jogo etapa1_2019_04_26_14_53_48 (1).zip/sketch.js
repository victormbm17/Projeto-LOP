/* 
    Equipe: 
        Victor Moura Botelho Medeiros - Subturma D (T01) (Líder) 
        André Luis Miranda dos Santos - Subturma D (T01)
        Etapa 1
*/



function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(100);
  ellipse(195, 350, 40, 40);
  square(175,50, 40);
}
